// Firebase imports
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.0.0/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/12.0.0/firebase-analytics.js";

const firebaseConfig = {
  apiKey: "AIzaSyBBFDXX4JOEOiye9LO2lqI_kwGW-7v7KKQ",
  authDomain: "barcavibesofficial.firebaseapp.com",
  projectId: "barcavibesofficial",
  storageBucket: "barcavibesofficial.firebasestorage.app",
  messagingSenderId: "739455946346",
  appId: "1:739455946346:web:eec65e26d93f681020c413",
  measurementId: "G-F3JQ0J7SFN"
};

const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

// Your existing code starts below.../*==========================================
 BARCA VIBES OFFICIAL
 script.js - Part 1
 Built by Haneef Khatami
==========================================*/

// ================= Loader =================

window.addEventListener("load", () => {

    const loader = document.getElementById("loader");

    setTimeout(() => {

        loader.style.opacity = "0";

        loader.style.visibility = "hidden";

    }, 1200);

});

// ================= Mobile Menu =================

const menuBtn = document.getElementById("menuBtn");
const navbar = document.getElementById("navbar");

if (menuBtn && navbar) {

    menuBtn.addEventListener("click", () => {

        navbar.classList.toggle("active");

        const icon = menuBtn.querySelector("i");

        if (navbar.classList.contains("active")) {

            icon.classList.remove("fa-bars");
            icon.classList.add("fa-xmark");

        } else {

            icon.classList.remove("fa-xmark");
            icon.classList.add("fa-bars");

        }

    });

}

// Close menu when a link is clicked

document.querySelectorAll("#navbar a").forEach(link => {

    link.addEventListener("click", () => {

        navbar.classList.remove("active");

        const icon = menuBtn.querySelector("i");

        icon.classList.remove("fa-xmark");
        icon.classList.add("fa-bars");

    });

});

// ================= Music Button =================

const music = document.getElementById("bgMusic");
const musicBtn = document.getElementById("musicBtn");

if (music && musicBtn) {

    musicBtn.addEventListener("click", () => {

        if (music.paused) {

            music.play();

            musicBtn.innerHTML =
            '<i class="fa-solid fa-pause"></i>';

        } else {

            music.pause();

            musicBtn.innerHTML =
            '<i class="fa-solid fa-music"></i>';

        }

    });

}

// ================= Scroll To Top =================

const scrollBtn = document.getElementById("scrollTop");

window.addEventListener("scroll", () => {

    if (window.scrollY > 400) {

        scrollBtn.style.display = "flex";

    } else {

        scrollBtn.style.display = "none";

    }

});

scrollBtn.addEventListener("click", () => {

    window.scrollTo({

        top: 0,

        behavior: "smooth"

    });

});
/*==========================================
 SCRIPT.JS - PART 2
 Animations & Effects
==========================================*/

// ================= Fade Animation =================

const fadeElements = document.querySelectorAll(".fade");

const observer = new IntersectionObserver((entries)=>{

entries.forEach(entry=>{

if(entry.isIntersecting){

entry.target.classList.add("show");

}

});

},{
threshold:0.2
});

fadeElements.forEach(el=>observer.observe(el));


// ================= Animated Counter =================

function animateCounter(id,target){

const counter=document.getElementById(id);

if(!counter) return;

let value=0;

const speed=Math.ceil(target/120);

const timer=setInterval(()=>{

value+=speed;

if(value>=target){

value=target;

clearInterval(timer);

}

counter.innerHTML=value.toLocaleString();

},20);

}

animateCounter("fansCount",500000);
animateCounter("newsCount",850);
animateCounter("galleryCount",2400);


// ================= Hero Text Animation =================

const heroTitle=document.querySelector(".hero h1");

if(heroTitle){

setInterval(()=>{

heroTitle.classList.toggle("pulse");

},1800);

}


// ================= Gallery Click Preview =================

document.querySelectorAll(".gallery-grid img").forEach(img=>{

img.addEventListener("click",()=>{

const overlay=document.createElement("div");

overlay.style.position="fixed";
overlay.style.top="0";
overlay.style.left="0";
overlay.style.width="100%";
overlay.style.height="100%";
overlay.style.background="rgba(0,0,0,.95)";
overlay.style.display="flex";
overlay.style.justifyContent="center";
overlay.style.alignItems="center";
overlay.style.zIndex="999999";

const preview=document.createElement("img");

preview.src=img.src;
preview.style.maxWidth="90%";
preview.style.maxHeight="90%";
preview.style.borderRadius="15px";

overlay.appendChild(preview);

overlay.onclick=()=>overlay.remove();

document.body.appendChild(overlay);

});

});


// ================= Current Year =================

const year=document.getElementById("year");

if(year){

year.innerHTML=new Date().getFullYear();

}
/*==========================================
 SCRIPT.JS - PART 3
 Navbar | Active Links | Hero | Stats
==========================================*/

// ================= Sticky Header =================

const header = document.querySelector(".header");

window.addEventListener("scroll", () => {

    if (window.scrollY > 50) {

        header.style.background = "rgba(5,10,20,.95)";
        header.style.boxShadow = "0 8px 25px rgba(0,0,0,.4)";

    } else {

        header.style.background = "rgba(0,0,0,.55)";
        header.style.boxShadow = "none";

    }

});


// ================= Active Navigation =================

const currentPage =
window.location.pathname.split("/").pop();

document.querySelectorAll("#navbar a").forEach(link=>{

const href = link.getAttribute("href");

if(href === currentPage || (currentPage==="" && href==="index.html")){

link.classList.add("active");

}

});


// ================= Hero Parallax =================

const hero = document.querySelector(".hero");

window.addEventListener("scroll",()=>{

if(hero){

hero.style.backgroundPositionY =
window.scrollY * 0.4 + "px";

}

});


// ================= Floating Cards =================

document.querySelectorAll(".stat-card").forEach((card,index)=>{

card.style.animation =
`floatCard 3s ease-in-out ${index*0.25}s infinite`;

});


// ================= News Card Hover =================

document.querySelectorAll(".news-card").forEach(card=>{

card.addEventListener("mouseenter",()=>{

card.style.transform="translateY(-12px) scale(1.02)";

});

card.addEventListener("mouseleave",()=>{

card.style.transform="translateY(0) scale(1)";

});

});


// ================= Gallery Hover =================

document.querySelectorAll(".gallery-grid img").forEach(img=>{

img.addEventListener("mouseenter",()=>{

img.style.transform="scale(1.06) rotate(1deg)";

});

img.addEventListener("mouseleave",()=>{

img.style.transform="scale(1) rotate(0deg)";

});

});


// ================= Welcome Message =================

console.log("%c⚽ Barca Vibes Official","font-size:28px;color:#FFD700;font-weight:bold;");
console.log("%cBuilt with ❤️ by Haneef Khatami","font-size:16px;color:#00BFFF;");
console.log("%cIndependent FC Barcelona Fan Community","font-size:14px;color:#fff;");
