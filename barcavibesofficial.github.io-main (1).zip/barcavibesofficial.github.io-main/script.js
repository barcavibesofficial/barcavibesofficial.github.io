const API_TOKEN =
"6e65973ffb7e4e4e995cfd15aed8fb1a";

async function loadBarcelonaMatch() {
  try {
    const res = await fetch(
      "https://api.football-data.org/v4/teams/81/matches?status=LIVE",
      {
        headers: {
          "X-Auth-Token": API_TOKEN
        }
      }
    );

    const data = await res.json();
    console.log(data);
  } catch (e) {
    console.log(e);
  }
}

loadBarcelonaMatch();
// BarcaVibes Official Script

document.addEventListener("DOMContentLoaded", function () {

    // Mobile Menu
    const menuBtn = document.querySelector(".menu-btn");
    const nav = document.querySelector("nav");

    if (menuBtn && nav) {
        menuBtn.addEventListener("click", () => {
            nav.classList.toggle("active");
        });
    }

    // Current Year
    const year = document.getElementById("year");
    if (year) {
        year.textContent = new Date().getFullYear();
    }

    // Smooth Scroll
    document.querySelectorAll('a[href^="#"]').forEach(link => {
        link.addEventListener("click", function (e) {
            e.preventDefault();

            const target = document.querySelector(this.getAttribute("href"));

            if (target) {
                target.scrollIntoView({
                    behavior: "smooth"
                });
            }
        });
    });

    // Page Loaded
    console.log("BarcaVibes Official Loaded Successfully");

});
console.log("BarcaVibes Official Loaded Successfully");

});

// Paste the LIVE MATCH code here
const API_TOKEN = "6e65973ffb7e4e4e995cfd15aed8fb1a";
async function updateLiveMatch() {

    try {

        const response = await fetch(
            "https://api.football-data.org/v4/teams/81/matches?status=LIVE",
            {
                headers: {
                    "X-Auth-Token": API_TOKEN
                }
            }
        );

        const data = await response.json();

        if (!data.matches || data.matches.length === 0) {

            document.getElementById("competition").textContent = "No Live Barcelona Match";
            document.getElementById("homeTeam").textContent = "Barcelona";
            document.getElementById("awayTeam").textContent = "-";
            document.getElementById("homeScore").textContent = "-";
            document.getElementById("awayScore").textContent = "-";
            document.getElementById("matchMinute").textContent = "Waiting for kickoff...";
            document.getElementById("stadium").textContent = "";

            return;
        }

        const match = data.matches[0];

        document.getElementById("competition").textContent =
            match.competition.name;

        document.getElementById("homeTeam").textContent =
            match.homeTeam.shortName;

        document.getElementById("awayTeam").textContent =
            match.awayTeam.shortName;

        document.getElementById("homeScore").textContent =
            match.score.fullTime.home ?? 0;

        document.getElementById("awayScore").textContent =
            match.score.fullTime.away ?? 0;

        document.getElementById("matchMinute").textContent =
            "Status: " + match.status;

        document.getElementById("stadium").textContent =
            "Venue: " + (match.venue || "Unknown");

    } catch (error) {

        console.log(error);

    }

}

updateLiveMatch();

setInterval(updateLiveMatch,60000);...
